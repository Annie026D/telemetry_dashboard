/*
 * ================================================================
 * DRIVE & PHYSICAL CONTROL PANEL
 * ================================================================
 *
 * IMPORTANT:
 *
 * 1. Every telemetry field is tracked independently.
 * 2. Identity = SOURCE IP + DEVICE + CHANNEL + FIELD.
 * 3. Physical buttons are momentary indications.
 * 4. Physical switches are ON/OFF indications.
 * 5. Knobs show their actual telemetry value.
 * 6. No commands are sent from this page.
 * 7. When the source device stops sending telemetry, its controls
 *    automatically return to their safe visual state.
 *
 * ================================================================
 */

const driveState = {};
const latest = {};
const history = {};

/*
 * A control/telemetry value is considered LIVE only while
 * fresh packets are actually arriving.
 *
 * This prevents old database values from appearing as if
 * the simulator is still running.
 */
const LIVE_TIMEOUT_MS = 5000;
/*
 * Device/control telemetry timeout.
 *
 * We use the packet receive time, not the browser page load time.
 */
const DRIVE_TELEMETRY_TIMEOUT_MS = 5000;

/*
 * Last packet received from each source/device.
 *
 * This is important for momentary controls. If a device sends
 * several fields in separate packets, the control state remains
 * valid while the device is still actively transmitting.
 */
const deviceLastRx = {};


/* ================================================================
   ACTUAL PHYSICAL CONTROLS
   ================================================================ */

const BUTTON_IDS = [
  "DRIVES_RESET",
  "OPTICS_RESET",
  "LRF_RESET",
  "CCE_RESET",
  "PARK",
  "ABORT",
  "COMBAT",
  "BCU",
  "PREPAR",
  "UNCAG",
  "DAY",
  "LOW_LIGHT",
  "THERMAL",
  "DROP",
  "FIRE",
  "LRF",
  "GButton1",
  "GButton2",
  "GButton3",
  "GButton4",
  "GButton5",
  "GButton6"
];

const SWITCH_IDS = [
  "MAIN_POWER_ON",
  "DRIVES_ON",
  "OPTICS_ON",
  "LRF_ON",
  "CCE_ON",
  "LOCK",
  "STRELETS_CH1_ON",
  "STRELETS_CH2_ON",
  "SINGLE",
  "CTRL_SRC_WCS",
  "HEAT_FILTER_ON",
  "LAUNCH_KEY_EN",
  "TARGET_SPEED_FAST",
  "CHASE_HEAD",
  "CHASE_TAIL",
  "TARGET_SPEED_SLOW",
  "CTRL_SRC_CCE",
  "SALVO",
  "UNLOCK"
];

const KNOB_IDS = [
  "MODE",
  "FREQUENCY"
];


/* ================================================================
   BASIC HELPERS
   ================================================================ */

function db() {
  return App.db || "";
}


function key(r) {
  return String(
    r?.key ??
    r?.value_key ??
    r?.field_name ??
    ""
  ).trim();
}


function rawDevice(r) {
  return String(
    r?.device ??
    r?.device_name ??
    ""
  ).trim();
}


function device(r) {
  try {
    return canonicalDeviceName(rawDevice(r));
  } catch (_) {
    return rawDevice(r);
  }
}


function channel(r) {
  return String(
    r?.channel ??
    r?.channel_name ??
    ""
  ).trim();
}


function sourceIp(r) {
  return String(
    r?.source_ip ??
    r?.src_ip ??
    r?.ip ??
    ""
  ).trim();
}


function sourcePort(r) {
  return r?.source_port ??
    r?.src_port ??
    "";
}


function value(r) {

  if (r?.value_type === "text") {
    return r.value_text ?? "";
  }

  if (
    r?.value_type === "REAL" ||
    r?.value_type === "real"
  ) {
    return r.value_num ??
      r.value ??
      "";
  }

  return (
    r?.value ??
    r?.value_num ??
    r?.value_text ??
    ""
  );
}


function valueType(r) {

  if (r?.value_type) {
    return String(r.value_type);
  }

  const v = value(r);

  if (typeof v === "number") {
    return "REAL";
  }

  if (typeof v === "boolean") {
    return "BOOLEAN";
  }

  return "TEXT";
}


function timestamp(r) {
  return String(
    r?.timestamp ??
    r?.server_rx_ts ??
    r?.ts ??
    r?.time ??
    new Date().toISOString()
  );
}


function parseNumber(v) {

  if (
    typeof v === "number" &&
    Number.isFinite(v)
  ) {
    return v;
  }

  if (typeof v !== "string") {
    return null;
  }

  const s = v.trim();

  if (!s) {
    return null;
  }

  const n = Number(s);

  return Number.isFinite(n)
    ? n
    : null;
}


function escapeHtml(v) {

  if (typeof esc === "function") {
    return esc(String(v ?? ""));
  }

  return String(v ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


function formatValue(v) {

  if (
    v === null ||
    v === undefined ||
    v === ""
  ) {
    return "--";
  }

  if (typeof v === "number") {

    return Number.isInteger(v)
      ? String(v)
      : String(Number(v.toFixed(6)));
  }

  return String(v);
}


function formatTime(v) {

  if (!v) {
    return "--";
  }

  const d = new Date(v);

  if (Number.isNaN(d.getTime())) {
    return String(v);
  }

  return d.toLocaleTimeString();
}


/* ================================================================
   DEVICE / FIELD IDENTITY
   ================================================================ */

function makeId(r) {

  return [
    sourceIp(r),
    device(r),
    channel(r),
    key(r)
  ].join("::");
}


function deviceIdentity(r) {

  return [
    sourceIp(r),
    device(r)
  ].join("::");
}


/* ================================================================
   FRESHNESS
   ================================================================ */

function getReceiveTime(r) {

  if (
    r &&
    Number.isFinite(Number(r._receivedAtMs))
  ) {
    return Number(r._receivedAtMs);
  }

  const ts = Date.parse(timestamp(r));

  if (Number.isFinite(ts)) {
    return ts;
  }

  return 0;
}


function isFresh(r) {

  if (!r) {
    return false;
  }

  const id = deviceIdentity(r);

  /*
   * If we have received a packet from this source/device recently,
   * the device is still alive.
   */
  const lastDevicePacket =
    Number(deviceLastRx[id] || 0);

  if (lastDevicePacket > 0) {

    return (
      Date.now() - lastDevicePacket
    ) <= DRIVE_TELEMETRY_TIMEOUT_MS;
  }

  /*
   * Fallback to the individual field timestamp.
   */
  const received =
    getReceiveTime(r);

  if (!received) {
    return false;
  }

  return (
    Date.now() - received
  ) <= DRIVE_TELEMETRY_TIMEOUT_MS;
}


/*
 * A control is active only when the source device is still alive.
 */
function controlActive(r) {

  if (!r || !isFresh(r)) {
    return false;
  }

  const v = value(r);

  const s =
    String(v)
      .trim()
      .toLowerCase();

  return [
    "1",
    "true",
    "on",
    "active",
    "enabled",
    "online",
    "alive",
    "pressed",
    "set",
    "high"
  ].includes(s)
  ||
  (
    typeof v === "number" &&
    Number.isFinite(v) &&
    v > 0.5
  )
  ||
  (
    typeof v === "string" &&
    Number.isFinite(Number(v)) &&
    Number(v) > 0.5
  );
}


/* ================================================================
   DRIVE IDENTIFICATION
   ================================================================ */

function isDriveRow(r) {
  const d = device(r).toUpperCase();
  const ch = channel(r).toUpperCase();
  const k = key(r).toUpperCase();

  /*
   * DRIVE telemetry can arrive through:
   *
   *   DRIVE_UNIT
   *   DRIVE
   *   LCU_UNIT
   *
   * The transport channel is also authoritative.
   */
  if (
    d === "DRIVE_UNIT" ||
    d === "DRIVE" ||
    d.includes("DRIVE_UNIT")
  ) {
    return true;
  }

  /*
   * LCU transport carries the physical DRIVE feedback block.
   */
  if (
    d === "LCU_UNIT" &&
    (
      ch === "LCU_TRANSPORT" ||
      ch === "DRIVE_WCS" ||
      ch === "TRACKER_PUBLISH"
    )
  ) {
    return true;
  }

  /*
   * Some packets may not carry a reliable device name.
   * Keep obvious DRIVE fields visible rather than dropping them.
   */
  if (
    ch === "DRIVE_WCS" ||
    ch === "TRACKER_PUBLISH"
  ) {
    return true;
  }

  const driveField =
    /(^|_)(RPM|BODY_RPM|CURRENT|ACTUAL_CURRENT|VOLTAGE|DCBUS|DCBUS_VOLT|TORQUE|VELOCITY|SPEED|POSITION|ANGLE|PAN|TILT|ACCEL|DECEL|FAULT|DRIVE_CONNECTED|MOTOR|TEMPERATURE|TEMP)(_|$)/i;

  return driveField.test(k);
}

function isControlId(k) {

  const normalized =
    String(k)
      .trim()
      .toUpperCase();

  return (
    BUTTON_IDS.some(
      x => x.toUpperCase() === normalized
    )
    ||
    SWITCH_IDS.some(
      x => x.toUpperCase() === normalized
    )
    ||
    KNOB_IDS.some(
      x => x.toUpperCase() === normalized
    )
  );
}


/* ================================================================
   EXACT CONTROL LOOKUP
   ================================================================ */
function isFresh(row) {
  if (!row) {
    return false;
  }

  /*
   * Prefer the actual telemetry timestamp when available.
   */
  const ts = timestamp(row);
  const t = Date.parse(ts);

  if (Number.isFinite(t)) {
    return (Date.now() - t) <= LIVE_TIMEOUT_MS;
  }

  /*
   * Fallback to browser receive time.
   */
  if (row._lastSeen) {
    return (Date.now() - row._lastSeen) <= LIVE_TIMEOUT_MS;
  }

  return false;
}


function findControlRow(id) {

  const target =
    String(id)
      .trim()
      .toUpperCase();

  const candidates =
    Object.values(latest)
      .filter(isFresh);

  /*
   * 1. Exact match:
   *
   * DRIVES_RESET
   */
  let row =
    candidates.find(r =>
      key(r)
        .trim()
        .toUpperCase() === target
    );

  if (row) {
    return row;
  }

  /*
   * 2. Prefixed/suffixed match:
   *
   * buttons_DRIVES_RESET
   * button_DRIVES_RESET
   * switches_MAIN_POWER_ON
   * switch_MAIN_POWER_ON
   * controls_MAIN_POWER_ON
   */
  row =
    candidates.find(r => {

      const k =
        key(r)
          .trim()
          .toUpperCase();

      return (
        k.endsWith("." + target) ||
        k.endsWith("_" + target) ||
        k.endsWith("-" + target)
      );
    });

  return row || null;
}

/* ================================================================
   LIVE PAYLOAD
   ================================================================ */

function rowsFromMessage(msg) {

  if (!msg) {
    return [];
  }

  const rows =
    liveRowsFromScadaEvent(msg);

  const now =
    Date.now();

  return rows.map(row => {

    const normalizedDevice =
      canonicalDeviceName(
        row.device ||
        row.device_name ||
        canonicalDeviceFromChannel(
          row.channel ||
          row.channel_name ||
          msg.channel ||
          msg.channel_name ||
          ""
        )
      );

    const normalizedIp =
      row.source_ip ||
      msg.source_ip ||
      "";

    const normalizedChannel =
      row.channel ||
      row.channel_name ||
      msg.channel ||
      msg.channel_name ||
      "";

    return {
      ...row,

      device:
        normalizedDevice,

      source_ip:
        normalizedIp,

      source_port:
        row.source_port ||
        msg.source_port ||
        0,

      channel:
        normalizedChannel,

      timestamp:
        row.timestamp ||
        row.server_rx_ts ||
        msg.timestamp ||
        msg.server_rx_ts ||
        new Date().toISOString(),

      /*
       * Browser receive timestamp.
       */
      _receivedAtMs:
        now
    };
  });
}


/* ================================================================
   UPDATE LIVE STATE
   ================================================================ */

function updateRows(rows) {

  if (!Array.isArray(rows)) {
    return;
  }

  rows.forEach(r => {

    const k = key(r);

    if (!k) {
      return;
    }

    const d = device(r);
    const ip = String(r.source_ip || "");
    const ch = String(r.channel || "");

    /*
     * Real telemetry identity:
     *
     * SOURCE IP
     *     +
     * DEVICE
     *     +
     * CHANNEL
     *     +
     * FIELD
     */
    const id =
      ip +
      "::" +
      d +
      "::" +
      ch +
      "::" +
      k;

    const previous =
      latest[id];

    const changed =
      previous !== undefined &&
      String(value(previous)) !==
      String(value(r));

    /*
     * Browser receive time.
     *
     * This is critical for determining whether
     * the simulator is still alive.
     */
    latest[id] = {
      ...r,

      device: d,

      source_ip: ip,

      channel: ch,

      _lastSeen: Date.now()
    };

    driveState[id] = {
      changed,
      at: Date.now()
    };

    /*
     * Only collect graph history for
     * genuinely received numeric values.
     */
    updateHistory(id, latest[id]);
  });

  render();
}


/* ================================================================
   DRIVE SUMMARY
   ================================================================ */

function renderSummary(driveRows) {

  const numeric =
    driveRows.filter(
      r => parseNumber(value(r)) !== null
    );

  const sourceIps =
    [
      ...new Set(
        driveRows
          .map(sourceIp)
          .filter(Boolean)
      )
    ];

  const channels =
    [
      ...new Set(
        driveRows
          .map(channel)
          .filter(Boolean)
      )
    ];

  const freshRows =
    driveRows.filter(isFresh);

  $("summary").innerHTML = [

    {
      label: "TOTAL FIELDS",
      value: driveRows.length,
      sub: "ALL RECEIVED"
    },

    {
      label: "NUMERIC",
      value: numeric.length,
      sub: "PLOT CAPABLE"
    },

    {
      label: "SOURCE IP",
      value: sourceIps.length,
      sub:
        sourceIps.join(", ") || "--"
    },

    {
      label: "CHANNELS",
      value: channels.length,
      sub:
        channels.join(", ") || "--"
    }

  ].map(x => `
    <div class="metric">

      <span>${escapeHtml(x.label)}</span>

      <strong>${escapeHtml(x.value)}</strong>

      <small>${escapeHtml(x.sub)}</small>

    </div>
  `).join("");

  $("driveFieldCount").textContent =
    String(driveRows.length);

  $("telemetryCount").textContent =
    `${driveRows.length} FIELDS`;

  $("driveSource").textContent =
    sourceIps.length
      ? `SOURCE: ${sourceIps.join(" · ")}`
      : "SOURCE: --";

  if (freshRows.length) {

    $("driveConnection").textContent =
      "ONLINE";

    $("driveConnection")
      .classList.add("online");

  } else {

    $("driveConnection").textContent =
      "OFFLINE";

    $("driveConnection")
      .classList.remove("online");
  }

  const latestTime =
    driveRows
      .map(timestamp)
      .sort()
      .at(-1);

  $("driveLastRx").textContent =
    latestTime
      ? formatTime(latestTime)
      : "--";
}


/* ================================================================
   COMPLETE DRIVE TABLE
   ================================================================ */

function renderDriveTable(driveRows) {

  const search =
    String(
      $("driveSearch")?.value || ""
    )
      .trim()
      .toLowerCase();

  const filtered =
    search
      ? driveRows.filter(r => {

          const text = [
            key(r),
            value(r),
            device(r),
            sourceIp(r),
            channel(r)
          ]
            .join(" ")
            .toLowerCase();

          return text.includes(search);
        })
      : driveRows;

  if (!filtered.length) {

    $("allDriveFields").innerHTML = `
      <tr>
        <td colspan="6"
            class="empty-cell">

          ${
            driveRows.length
              ? "No fields match the filter."
              : "Waiting for DRIVE telemetry..."
          }

        </td>
      </tr>
    `;

    return;
  }

  $("allDriveFields").innerHTML =
    filtered
      .sort((a, b) =>
        key(a).localeCompare(
          key(b)
        )
      )
      .map(r => {

        const id =
          makeId(r);

        const st =
          driveState[id] || {};

        const fresh =
          isFresh(r);

        return `
          <tr class="
            ${
              st.changed &&
              Date.now() - st.at < 1500
                ? "row-changed"
                : ""
            }
          ">

            <td class="field-name">
              ${escapeHtml(key(r))}
            </td>

            <td class="field-value">
              ${escapeHtml(
                formatValue(value(r))
              )}
            </td>

            <td>
              ${escapeHtml(
                valueType(r)
              )}
            </td>

            <td>
              ${escapeHtml(
                sourceIp(r) || "--"
              )}

              ${
                sourcePort(r)
                  ? ":" +
                    escapeHtml(
                      sourcePort(r)
                    )
                  : ""
              }
            </td>

            <td>
              ${escapeHtml(
                channel(r) || "--"
              )}
            </td>

            <td>
              ${escapeHtml(
                formatTime(timestamp(r))
              )}

              ${
                fresh
                  ? ""
                  : " · STALE"
              }
            </td>

          </tr>
        `;
      })
      .join("");
}


/* ================================================================
   LIVE GRAPH ENGINE
   ================================================================ */

function drawGraph(
  canvas,
  points,
  label
) {

  if (!canvas) {
    return;
  }

  const ctx =
    canvas.getContext("2d");

  const width =
    canvas.width =
      canvas.clientWidth *
      devicePixelRatio;

  const height =
    canvas.height =
      canvas.clientHeight *
      devicePixelRatio;

  ctx.clearRect(
    0,
    0,
    width,
    height
  );

  if (
    !points ||
    points.length < 2
  ) {

    ctx.font =
      `${12 * devicePixelRatio}px Arial`;

    ctx.fillText(
      "Waiting for trend data...",
      16 * devicePixelRatio,
      30 * devicePixelRatio
    );

    return;
  }

  const values =
    points.map(p => p.value);

  let min =
    Math.min(...values);

  let max =
    Math.max(...values);

  if (min === max) {

    const pad =
      Math.abs(min) * 0.05 || 1;

    min -= pad;
    max += pad;
  }

  const padX =
    12 * devicePixelRatio;

  const padY =
    12 * devicePixelRatio;

  const plotW =
    width - padX * 2;

  const plotH =
    height - padY * 2;

  ctx.lineWidth =
    1 * devicePixelRatio;

  ctx.strokeStyle =
    "rgba(120,160,190,.16)";

  for (let i = 0; i < 4; i++) {

    const y =
      padY +
      plotH * (i / 3);

    ctx.beginPath();

    ctx.moveTo(
      padX,
      y
    );

    ctx.lineTo(
      width - padX,
      y
    );

    ctx.stroke();
  }

  ctx.strokeStyle =
    "#22d3ee";

  ctx.lineWidth =
    2 * devicePixelRatio;

  ctx.beginPath();

  points.forEach((p, i) => {

    const x =
      padX +
      (
        i /
        Math.max(
          points.length - 1,
          1
        )
      ) *
      plotW;

    const y =
      padY +
      (
        1 -
        (
          (p.value - min) /
          (max - min)
        )
      ) *
      plotH;

    if (i === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  });

  ctx.stroke();

  const latestPoint =
    points[points.length - 1];

  ctx.fillStyle =
    "#e5f7ff";

  ctx.font =
    `700 ${13 * devicePixelRatio}px Arial`;

  ctx.fillText(
    formatValue(
      latestPoint.value
    ),
    padX,
    padY +
      14 *
      devicePixelRatio
  );

  ctx.fillStyle =
    "#7f9ab0";

  ctx.font =
    `${10 * devicePixelRatio}px Arial`;

  ctx.fillText(
    `MIN ${formatValue(min)}`,
    padX,
    height -
      4 *
      devicePixelRatio
  );

  ctx.textAlign =
    "right";

  ctx.fillText(
    `MAX ${formatValue(max)}`,
    width - padX,
    height -
      4 *
      devicePixelRatio
  );

  ctx.textAlign =
    "left";
}


function renderGraphs(driveRows) {

  const numericRows =
    driveRows
      .filter(
        r =>
          parseNumber(value(r)) !== null
      )
      .sort((a, b) =>
        key(a).localeCompare(
          key(b)
        )
      );

  if (!numericRows.length) {

    $("driveGraphs").innerHTML = `
      <div class="empty-panel">
        No numeric DRIVE telemetry received yet.
      </div>
    `;

    return;
  }

  $("driveGraphs").innerHTML =
    numericRows
      .map(r => {

        const id =
          makeId(r);

        return `
          <article
            class="graph-card"
            data-graph-id="${escapeHtml(id)}"
          >

            <div class="graph-header">

              <div>

                <span>LIVE TREND</span>

                <h3>
                  ${escapeHtml(key(r))}
                </h3>

              </div>

              <strong>
                ${escapeHtml(
                  formatValue(
                    value(r)
                  )
                )}
              </strong>

            </div>

            <canvas
              class="drive-chart">
            </canvas>

            <div class="graph-footer">

              <span>
                ${escapeHtml(
                  sourceIp(r) || "--"
                )}
              </span>

              <span>
                ${escapeHtml(
                  channel(r) || "--"
                )}
              </span>

            </div>

          </article>
        `;
      })
      .join("");

  document
    .querySelectorAll(".graph-card")
    .forEach(card => {

      const id =
        card.dataset.graphId;

      const canvas =
        card.querySelector("canvas");

      drawGraph(
        canvas,
        history[id] || [],
        id
      );
    });
}


/* ================================================================
   PHYSICAL BUTTON PANEL
   ================================================================ */

function renderButtons() {

  $("buttonPanel").innerHTML =
    BUTTON_IDS
      .map((id, index) => {

        const r =
          findControlRow(id);

        const fresh =
          r &&
          isFresh(r);

        const on =
          fresh &&
          controlActive(r);

        let state =
          "NO TELEMETRY";

        if (r && fresh) {

          state =
            on
              ? "PRESSED"
              : "IDLE";

        } else if (r) {

          state =
            "OFFLINE";
        }

        return `
          <article
            class="
              physical-button
              ${on ? "control-active" : ""}
              ${r ? "control-seen" : "control-unseen"}
              ${!fresh && r ? "control-stale" : ""}
            "
            data-control-id="${escapeHtml(id)}"
          >

            <div
              class="
                button-lamp
                ${on ? "lit" : ""}
              "
            >
              <i></i>
            </div>

            <div class="control-name">
              ${escapeHtml(id)}
            </div>

            <div class="control-channel">
              CH ${index + 1}
            </div>

            <div class="control-state">
              ${escapeHtml(state)}
            </div>

          </article>
        `;
      })
      .join("");
}


/* ================================================================
   PHYSICAL SWITCH PANEL
   ================================================================ */

function renderSwitches() {

  $("switchPanel").innerHTML =
    SWITCH_IDS
      .map((id, index) => {

        const r =
          findControlRow(id);

        const fresh =
          r &&
          isFresh(r);

        const on =
          fresh &&
          controlActive(r);

        let state =
          "NO TELEMETRY";

        if (r && fresh) {

          state =
            on
              ? "ON"
              : "OFF";

        } else if (r) {

          state =
            "OFFLINE";
        }

        return `
          <article
            class="
              physical-switch
              ${on ? "control-active" : ""}
              ${r ? "control-seen" : "control-unseen"}
              ${!fresh && r ? "control-stale" : ""}
            "
            data-control-id="${escapeHtml(id)}"
          >

            <div class="switch-body">

              <div
                class="
                  switch-lever
                  ${on ? "switch-on" : ""}
                "
              >
                <span></span>
              </div>

            </div>

            <div class="switch-info">

              <div class="control-name">
                ${escapeHtml(id)}
              </div>

              <div class="control-channel">
                CH ${index + 16}
              </div>

              <div class="control-state">
                ${escapeHtml(state)}
              </div>

            </div>

          </article>
        `;
      })
      .join("");
}


/* ================================================================
   PHYSICAL KNOBS
   ================================================================ */

function renderKnobs() {

  $("knobPanel").innerHTML =
    KNOB_IDS
      .map((id, index) => {

        const r =
          findControlRow(id);

        const fresh =
          r &&
          isFresh(r);

        const raw =
          fresh
            ? parseNumber(
                value(r)
              )
            : null;

        const angle =
          raw === null
            ? -45
            : Math.max(
                -135,
                Math.min(
                  135,
                  (
                    (raw % 100) /
                    100
                  ) *
                  270 -
                  135
                )
              );

        const display =
          !r
            ? "--"
            : !fresh
              ? "OFFLINE"
              : formatValue(
                  value(r)
                );

        return `
          <article
            class="
              physical-knob
              ${r ? "control-seen" : "control-unseen"}
              ${!fresh && r ? "control-stale" : ""}
            "
            data-control-id="${escapeHtml(id)}"
          >

            <div class="knob-face">

              <div
                class="knob-pointer"
                style="
                  transform:
                    rotate(${angle}deg)
                "
              ></div>

            </div>

            <div class="knob-info">

              <div class="control-name">
                ${escapeHtml(id)}
              </div>

              <div class="control-channel">
                CH ${index + 52}
              </div>

              <strong>
                ${escapeHtml(display)}
              </strong>

            </div>

          </article>
        `;
      })
      .join("");
}


/* ================================================================
   CONTROL TELEMETRY TABLE
   ================================================================ */

function renderControlTelemetry() {

 const rows =
    Object.values(latest)
      .filter(r =>
        isFresh(r) &&
        isControlId(key(r))
      )
      .sort((a, b) =>
        key(a).localeCompare(key(b))
      );
  if (!rows.length) {

    $("controlTelemetry").innerHTML = `
      <tr>
        <td
          colspan="6"
          class="empty-cell"
        >
          No control telemetry received yet.
          Physical controls remain visible.
        </td>
      </tr>
    `;

    return;
  }

  $("controlTelemetry").innerHTML =
    rows.map(r => {

      const fresh =
        isFresh(r);

      let display =
        formatValue(value(r));

      if (!fresh) {
        display = "OFFLINE";
      }

      return `
        <tr>

          <td class="field-name">
            ${escapeHtml(key(r))}
          </td>

          <td>
            ${escapeHtml(key(r))}
          </td>

          <td class="field-value">
            ${escapeHtml(display)}
          </td>

          <td>
            ${escapeHtml(
              device(r) || "--"
            )}
          </td>

          <td>
            ${escapeHtml(
              sourceIp(r) || "--"
            )}
          </td>

          <td>
            ${escapeHtml(
              formatTime(timestamp(r))
            )}
          </td>

        </tr>
      `;
    })
    .join("");
}


/* ================================================================
   COMPLETE RENDER
   ================================================================ */
function render() {

  const freshRows =
    Object.values(latest)
      .filter(isFresh);

  const driveRows =
    freshRows
      .filter(isDriveRow);

  renderSummary(driveRows);

  renderDriveTable(driveRows);

  renderGraphs(driveRows);

  renderButtons();

  renderSwitches();

  renderKnobs();

  renderControlTelemetry();
}


/* ================================================================
   WEBSOCKET
   ================================================================ */

onScadaEvent(batch => {

  if (!Array.isArray(batch)) {
    return;
  }

  batch.forEach(message => {

    const rows =
      rowsFromMessage(
        message
      );

    updateRows(rows);
  });
});


window.addEventListener(
  "scada:connected",
  render
);


/* ================================================================
   INITIAL LOAD
   ================================================================ */

document.addEventListener(
  "DOMContentLoaded",
  async () => {

    await loadDbSelect(
      $("dbSelect")
    );

    App.db =
      $("dbSelect").value || "";

    initScadaSocket();

    /*
     * Database snapshot is useful for immediately populating
     * the page, but its timestamps determine whether it is still
     * considered LIVE.
     */
    try {

      const data =
        await api(
          "/api/all?db=" +
          encodeURIComponent(db()) +
          "&range=30s"
        );

      if (Array.isArray(data)) {

        /*
         * Database rows are historical rows.
         * Assign their receive time from their timestamp.
         */
        const now = Date.now();

        data.forEach(row => {

          const ts =
            Date.parse(
              timestamp(row)
            );

          row._receivedAtMs =
            Number.isFinite(ts)
              ? ts
              : now;
        });

        /*
         * Establish last packet time per source/device.
         */
        data.forEach(row => {

          const id =
            deviceIdentity(row);

          const ts =
            Number(
              row._receivedAtMs ||
              0
            );

          if (
            ts >
            Number(deviceLastRx[id] || 0)
          ) {
            deviceLastRx[id] = ts;
          }
        });

        updateRows(data);
      }

    } catch (error) {

      console.error(
        "Unable to load initial DRIVE telemetry:",
        error
      );
    }

    $("driveSearch")
      ?.addEventListener(
        "input",
        render
      );

    /*
     * This is what makes an old ON state disappear
     * after the simulator/device stops.
     */
    setInterval(
      render,
      1000
    );
  }
);